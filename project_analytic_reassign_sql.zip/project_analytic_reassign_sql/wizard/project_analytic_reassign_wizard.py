
from odoo import models, fields, api, _, tools
from odoo.exceptions import UserError, AccessError

class ProjectAnalyticReassignWizard(models.TransientModel):
    _name = "project.analytic.reassign.wizard"
    _description = "Project & Analytic Reassignment (SQL Engine)"

    company_id = fields.Many2one('res.company', required=True, default=lambda self: self.env.company)
    # Optional temporal filter for accounting/stock/expenses
    date_from = fields.Date()
    date_to = fields.Date()

    # Project remap (header-level project_id on various docs)
    source_project_id = fields.Many2one('project.project', string="Source Project")
    target_project_id = fields.Many2one('project.project', string="Target Project")

    # Analytic remap (distribution key remap)
    source_analytic_id = fields.Many2one('account.analytic.account', string="Source Analytic")
    target_analytic_id = fields.Many2one('account.analytic.account', string="Target Analytic")

    # Scope
    include_sale = fields.Boolean("Sales Orders", default=True)
    include_purchase = fields.Boolean("Purchase Orders", default=True)
    include_account = fields.Boolean("Invoices/Bills/Journal Entries", default=True)
    include_expense = fields.Boolean("Expenses", default=True)
    include_stock = fields.Boolean("Stock", default=True)

    # Behavior
    force_all_to_target = fields.Boolean(
        "Force All Distribution To Target",
        help="If enabled and Source Analytic is empty, move the entire distribution to the target analytic (100%%)."
    )
    edit_posted_as_fallback = fields.Boolean(
        "Fallback: Edit Analytic Items When Unpost Blocked",
        default=True,
        help="If a posted journal entry cannot be set to draft due to lock date or policy, "
             "update related analytic items (account.analytic.line) to the target analytic."
    )

    # Results
    log_message = fields.Text(readonly=True)

    def _date_clause(self, column):
        """Return SQL and params for date filters on 'column'."""
        sql = ""
        params = []
        if self.date_from:
            sql += f" AND {column} >= %s"
            params.append(self.date_from)
        if self.date_to:
            sql += f" AND {column} <= %s"
            params.append(self.date_to)
        return sql, params

    def _jsonb_move_key_sql(self, table, json_field, date_col=None):
        """Build an UPDATE ... SET json = (json - src) || jsonb_build_object(dst, ...)
        Only rows where json has the source key will be touched.
        Merge into existing dst if any.
        """
        src_key = str(self.source_analytic_id.id) if self.source_analytic_id else None
        dst_key = str(self.target_analytic_id.id) if self.target_analytic_id else None
        if not dst_key:
            raise UserError(_("Target Analytic is required for analytic distribution reassignment."))

        if not src_key and not self.force_all_to_target:
            # Nothing to do safely if we don't know what to replace and we're not forcing all
            return None, []

        # Build base WHERE with company (if exists on table)
        where_company = ""
        params = []
        try:
            # best-effort: assume company_id exists; if not, skip constraint
            self.env[table.replace('_', '.')]._fields['company_id']
            where_company = " AND company_id = %s"
            params.append(self.company_id.id)
        except Exception:
            pass

        # Date clause (if provided)
        date_sql = ""
        if date_col:
            d_sql, d_params = self._date_clause(date_col)
            date_sql += d_sql
            params += d_params

        if src_key:
            # Move only the source key
            sql = f"""
                UPDATE {table}
                   SET {json_field} = (
                        ({json_field})::jsonb - %s
                    ) || jsonb_build_object(%s,
                         COALESCE( ({json_field})::jsonb ->> %s, '0')::numeric
                       + COALESCE( ({json_field})::jsonb ->> %s, '0')::numeric
                   )
                 WHERE ({json_field})::jsonb ? %s
                   {where_company}
                   {date_sql}
            """
            params = [src_key, dst_key, src_key, dst_key, src_key] + params
            return tools.ustr(sql), params
        else:
            # Force-all: replace entire distribution with target=100
            sql = f"""
                UPDATE {table}
                   SET {json_field} = jsonb_build_object(%s, 100.0)
                 WHERE COALESCE({json_field}, '') != ''
                   {where_company}
                   {date_sql}
            """
            params = [dst_key] + params
            return tools.ustr(sql), params

    # ---------------------------
    # SALES / PURCHASE / EXPENSE
    # ---------------------------
    def _reassign_in_sale(self):
        cr = self.env.cr
        logs = []
        # Header project
        if self.source_project_id and self.target_project_id:
            cr.execute("""
                UPDATE sale_order so
                   SET project_id = %s
                 WHERE so.project_id = %s
                   AND so.company_id = %s
            """, [self.target_project_id.id, self.source_project_id.id, self.company_id.id])
            logs.append(_("SO: Header project_id updated."))

        # Lines analytic_distribution
        if self.target_analytic_id:
            sql, params = self._jsonb_move_key_sql('sale_order_line', 'analytic_distribution')
            if sql:
                cr.execute(sql, params)
                logs.append(_("SO: Lines analytic_distribution remapped."))
            elif self.force_all_to_target:
                cr.execute(sql, params)
                logs.append(_("SO: Lines analytic_distribution set to 100% target."))
        return logs

    def _reassign_in_purchase(self):
        cr = self.env.cr
        logs = []
        # Header project
        if self.source_project_id and self.target_project_id:
            cr.execute("""
                UPDATE purchase_order po
                   SET project_id = %s
                 WHERE po.project_id = %s
                   AND po.company_id = %s
            """, [self.target_project_id.id, self.source_project_id.id, self.company_id.id])
            logs.append(_("PO: Header project_id updated."))

        # Lines analytic_distribution
        if self.target_analytic_id:
            sql, params = self._jsonb_move_key_sql('purchase_order_line', 'analytic_distribution')
            if sql:
                cr.execute(sql, params)
                logs.append(_("PO: Lines analytic_distribution remapped."))
        return logs

    def _reassign_in_expense(self):
        cr = self.env.cr
        logs = []
        # Expenses analytic_distribution
        if self.target_analytic_id:
            sql, params = self._jsonb_move_key_sql('hr_expense', 'analytic_distribution', date_col='date')
            if sql:
                cr.execute(sql, params)
                logs.append(_("Expense: analytic_distribution updated."))
        # project_id on expense (if present)
        if self.source_project_id and self.target_project_id:
            cr.execute("""
                UPDATE hr_expense
                   SET project_id = %s
                 WHERE project_id = %s
                   AND company_id = %s
            """, [self.target_project_id.id, self.source_project_id.id, self.company_id.id])
            logs.append(_("Expense: project_id updated."))
        return logs

    # --------------
    # ACCOUNT MOVES
    # --------------
    def _unpost_update_repost(self):
        """Try to unpost -> update -> repost; if blocked, return list of affected move_line ids
        so fallback can adjust analytic items directly.
        """
        logs = []
        move_model = self.env['account.move']

        # Build WHERE chunk
        where = "WHERE aml.company_id = %s"
        params = [self.company_id.id]
        if self.date_from:
            where += " AND aml.date >= %s"
            params.append(self.date_from)
        if self.date_to:
            where += " AND aml.date <= %s"
            params.append(self.date_to)

        if self.source_analytic_id:
            where += " AND (aml.analytic_distribution)::jsonb ? %s"
            params.append(str(self.source_analytic_id.id))
        elif self.force_all_to_target:
            where += " AND COALESCE(aml.analytic_distribution, '') != ''"
        else:
            return logs, []

        # Draft moves: update AML JSON directly
        sql_update_draft = f"""
            UPDATE account_move_line aml
               SET analytic_distribution = (
                    (aml.analytic_distribution)::jsonb - %s
                ) || jsonb_build_object(%s,
                     COALESCE( (aml.analytic_distribution)::jsonb ->> %s, '0')::numeric
                   + COALESCE( (aml.analytic_distribution)::jsonb ->> %s, '0')::numeric
               )
            FROM account_move m
           WHERE aml.move_id = m.id
             AND m.state = 'draft'
             {where}
        """
        if self.source_analytic_id:
            self.env.cr.execute(sql_update_draft, [str(self.source_analytic_id.id), str(self.target_analytic_id.id),
                                                   str(self.source_analytic_id.id), str(self.target_analytic_id.id)] + params)
            logs.append(_("AML (draft): analytic_distribution remapped."))

        # Posted moves: collect
        self.env.cr.execute((f"""
            SELECT DISTINCT m.id
              FROM account_move_line aml
              JOIN account_move m ON m.id = aml.move_id
             {where} AND m.state = 'posted'
        """), params)
        move_ids = [r[0] for r in self.env.cr.fetchall()]
        fallback_aml_ids = []
        if move_ids:
            moves = move_model.sudo().browse(move_ids)
            for mv in moves:
                try:
                    # Try reset to draft
                    if hasattr(mv, 'button_draft'):
                        mv.sudo().button_draft()
                    else:
                        mv.sudo().action_unpost()
                    # Update its lines (SQL for speed)
                    if self.source_analytic_id:
                        self.env.cr.execute("""
                            UPDATE account_move_line aml
                               SET analytic_distribution = (
                                    (aml.analytic_distribution)::jsonb - %s
                                ) || jsonb_build_object(%s,
                                     COALESCE( (aml.analytic_distribution)::jsonb ->> %s, '0')::numeric
                                   + COALESCE( (aml.analytic_distribution)::jsonb ->> %s, '0')::numeric
                               )
                             WHERE aml.move_id = %s
                        """, [str(self.source_analytic_id.id), str(self.target_analytic_id.id),
                              str(self.source_analytic_id.id), str(self.target_analytic_id.id),
                              mv.id])
                    # Repost to rebuild Analytic Items
                    mv.sudo().action_post()
                except Exception:
                    # Unpost blocked (lock date / policy) -> fallback needed
                    self.env.cr.execute("""
                        SELECT aml.id
                          FROM account_move_line aml
                         WHERE aml.move_id = %s
                    """, [mv.id])
                    fallback_aml_ids += [r[0] for r in self.env.cr.fetchall()]
                    logs.append(_("Move %s skipped (cannot unpost): fallback to analytic items." % mv.name))
        return logs, fallback_aml_ids

    def _fallback_update_analytic_items(self, aml_ids):
        """Directly update account.analytic.line for given move_line ids, swapping source->target analytic."""
        if not aml_ids:
            return 0
        if not self.source_analytic_id or not self.target_analytic_id:
            return 0
        self.env.cr.execute("""
            UPDATE account_analytic_line aal
               SET account_id = %s
             WHERE aal.move_line_id = ANY(%s)
               AND aal.account_id = %s
               AND aal.company_id = %s
        """, [self.target_analytic_id.id, aml_ids, self.source_analytic_id.id, self.company_id.id])
        return self.env.cr.rowcount

    def _reassign_in_accounting(self):
        logs = []
        # First try proper unpost->edit->post; then fallback
        lgs, fallback_aml_ids = self._unpost_update_repost()
        logs += lgs
        if fallback_aml_ids and self.edit_posted_as_fallback:
            changed = self._fallback_update_analytic_items(fallback_aml_ids)
            logs.append(_("Fallback: %s analytic items re-mapped." % changed))
        return logs

    # -----
    # STOCK
    # -----
    def _reassign_in_stock(self):
        cr = self.env.cr
        logs = []
        # stock.move analytic_distribution (if present)
        try:
            if 'analytic_distribution' in self.env['stock.move']._fields and self.target_analytic_id:
                sql, params = self._jsonb_move_key_sql('stock_move', 'analytic_distribution', date_col='date')
                if sql:
                    cr.execute(sql, params)
                    logs.append(_("Stock Move: analytic_distribution updated."))
        except Exception:
            # Field may not exist depending on addons
            pass

        # stock.move.line analytic_distribution (if present)
        try:
            if 'analytic_distribution' in self.env['stock.move.line']._fields and self.target_analytic_id:
                sql, params = self._jsonb_move_key_sql('stock_move_line', 'analytic_distribution', date_col='date')
                if sql:
                    cr.execute(sql, params)
                    logs.append(_("Stock Move Line: analytic_distribution updated."))
        except Exception:
            pass

        # project_id on pickings if present
        if self.source_project_id and self.target_project_id and 'project_id' in self.env['stock.picking']._fields:
            cr.execute("""
                UPDATE stock_picking
                   SET project_id = %s
                 WHERE project_id = %s AND company_id = %s
            """, [self.target_project_id.id, self.source_project_id.id, self.company_id.id])
            logs.append(_("Pickings: project_id updated."))
        return logs

    # ---------------
    # MAIN ENTRYPOINT
    # ---------------
    def action_execute(self):
        if not (self.source_project_id or self.source_analytic_id or self.force_all_to_target):
            raise UserError(_("Provide at least Source Project or Source Analytic (or enable Force All)."))
        if self.source_project_id and not self.target_project_id:
            raise UserError(_("Target Project is required when Source Project is provided."))
        if (self.source_analytic_id or self.force_all_to_target) and not self.target_analytic_id:
            raise UserError(_("Target Analytic is required for analytic reassignment."))

        logs = []
        # SALES
        if self.include_sale:
            logs += self._reassign_in_sale()
        # PURCHASE
        if self.include_purchase:
            logs += self._reassign_in_purchase()
        # EXPENSE
        if self.include_expense:
            logs += self._reassign_in_expense()
        # ACCOUNTING
        if self.include_account:
            logs += self._reassign_in_accounting()
        # STOCK
        if self.include_stock:
            logs += self._reassign_in_stock()

        self.log_message = "\\n".join(l for l in logs if l)
        return {
            'type': 'ir.actions.act_window',
            'res_model': self._name,
            'res_id': self.id,
            'view_mode': 'form',
            'target': 'new'
        }
