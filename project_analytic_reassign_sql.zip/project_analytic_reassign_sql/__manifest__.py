{
    "name": "Project & Analytic Reassignment (SQL Engine)",
    "summary": "One-click reassignment of project and analytic distribution across SO/PO/Invoices/Bills/Expenses/Stock + analytic items",
    "version": "18.0.1.0.0",
    "author": "ChatGPT Assist",
    "license": "LGPL-3",
    "depends": [
        "account",
        "sale_management",
        "purchase",
        "hr_expense",
        "stock",
        "project",
        "analytic"
    ],
    "data": [
        "views/project_analytic_reassign_wizard_views.xml"
    ],
    "installable": true,
    "application": false
}